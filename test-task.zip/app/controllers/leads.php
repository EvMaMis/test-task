<?php

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addlead'])) {
    $api = curl_init();

    $data = [
        'firstName' => $_POST['fisrtName'],
        'lastName' => $_POST['lastName'],
        'phone' => $_POST['phone'],
        'email' => $_POST['email'],
        'box_id' => 28,
        'offer_id' => 5,
        'countyCode' => 'GB',
        'language' => 'en',
        'password' => 'qwerty12',
        'ip' => $_SERVER['REMOTE_ADDR'],
        'landingUrl' => $_SERVER['HTTP_REFERER'],
    ];
    curl_setopt($api, CURLOPT_URL, API_URL . 'addlead');
    curl_setopt($api, CURLOPT_POST, 1);
    curl_setopt($api, CURLOPT_HTTPHEADER, [
        'token' => TOKEN,
        'Content-Type: multipart/form-data',
    ]);
    curl_setopt($api, CURLOPT_POSTFIELDS, $data);
    $output = curl_exec($api);
    if($output === false) {
        print_r(curl_error($api));
    } else {
        echo "Данные успешно отправлены";
    }
    curl_close($api);

}

if($_SERVER['REQUEST_METHOD'] === 'GET') {
    $api = curl_init();
    curl_setopt($api, CURLOPT_URL, API_URL . 'getstatuses');
    curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($api, CURLOPT_HTTPHEADER, [
        'token' => TOKEN,
    ]);
    $leads = curl_exec($api);
    curl_close($api);

    if($leads === false) {
        echo "Ошибка получения данных";
    } else {
        echo "Данные получены";
    }
}

function dd($data) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}