<header style="display: flex; justify-content: space-around;">
    <div style="width: 10%;  text-align: center; border: 2px solid black; background: antiquewhite; padding: 3px">
        <a href="index.php" style="text-decoration: none; color: black;">Форма</a>
    </div>
    <div style="width: 10%; text-align: center; border: 2px solid black; background: antiquewhite; padding: 3px">
        <a href="results.php" style="text-decoration: none; color: black;">Результати</a>
    </div>
</header>