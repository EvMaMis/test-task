<?php
const ROOT = __DIR__;
const API_URL = "https://crm.belmar.pro/api/v1/";
const TOKEN = 'ba67df6a-a17c-476f-8e95-bcdb75ed3958';
