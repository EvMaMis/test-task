<?php
require_once("path.php");
require_once(ROOT . '/app/database/db.php');
?>
